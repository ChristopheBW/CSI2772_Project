CSI2772 lab3

Student info: 
Bowen Zeng 300115382 & Xiang Li 300056427
