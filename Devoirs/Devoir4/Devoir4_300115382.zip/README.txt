[CSI2772A] Lab4

Student info: 
- Bowen Zeng 300115382
- Xiang Li 300056427
