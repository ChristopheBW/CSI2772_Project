#ifndef MYFILE_H
#define MYFILE_H

#include <cstdlib>
#include <ctime>
#include <cassert>

#endif
